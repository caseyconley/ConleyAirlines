insert into reservation (reservation_id, trip_number, trip_date, seat_class)
values (1, 409, '05-MAY-2013', 'economy');
insert into reservation (reservation_id, trip_number, trip_date, seat_class)
values (2, 411, '05-MAY-2013', 'first');
insert into reservation (reservation_id, trip_number, trip_date, seat_class)
values (3, 8011, '05-MAY-2013', 'economy');
insert into reservation (reservation_id, trip_number, trip_date, seat_class)
values (4, 409, '05-MAY-2013', 'business');