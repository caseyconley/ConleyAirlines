insert into trip
(trip_number, trip_date, start_airport, end_airport)
values
(409, '05-MAY-2013', 'JFK', 'SFO');
insert into trip
(trip_number, trip_date, start_airport, end_airport)
values
(411, '05-MAY-2013', 'SFO', 'ORD');
insert into trip
(trip_number, trip_date, start_airport, end_airport)
values
(8011, '05-MAY-2013', 'ORD', 'LAX');