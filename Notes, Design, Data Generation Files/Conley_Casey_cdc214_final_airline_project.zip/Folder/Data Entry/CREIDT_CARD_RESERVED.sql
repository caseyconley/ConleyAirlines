insert into credit_card_reserved (card_num, reservation_id, trip_number, seat_class)
  values (6098453343845904, 1, 409, 'economy');
insert into credit_card_reserved (card_num, reservation_id, trip_number, seat_class)
  values (9288115810602904, 2, 411, 'first');
insert into credit_card_reserved (card_num, reservation_id, trip_number, seat_class)
  values (1035860602278262, 3, 8011, 'economy');
insert into credit_card_reserved (card_num, reservation_id, trip_number, seat_class)
  values (4488670974504203, 4, 409, 'business');