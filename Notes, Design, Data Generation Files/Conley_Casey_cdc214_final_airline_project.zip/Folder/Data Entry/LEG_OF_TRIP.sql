insert into leg_of_trip (trip_number, trip_date, leg_id)
  values (409, '05-MAY-2013', 1);
insert into leg_of_trip (trip_number, trip_date, leg_id)
  values (409, '05-MAY-2013', 2);
insert into leg_of_trip (trip_number, trip_date, leg_id)
  values (8011, '05-MAY-2013', 4);
insert into leg_of_trip (trip_number, trip_date, leg_id)
  values (411, '05-MAY-2013', 4);