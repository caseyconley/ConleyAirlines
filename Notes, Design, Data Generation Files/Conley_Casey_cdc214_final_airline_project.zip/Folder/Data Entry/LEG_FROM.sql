insert into leg_from (leg_id, airport)
  values (1, 'JFK');
insert into leg_from (leg_id, airport)
  values (2, 'ORD');
insert into leg_from (leg_id, airport)
  values (3, 'ORD');
insert into leg_from (leg_id, airport)
  values (4, 'SFO');