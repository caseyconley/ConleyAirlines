insert into leg_to (leg_id, airport)
  values (1, 'ORD');
insert into leg_to (leg_id, airport)
  values (2, 'SFO');
insert into leg_to (leg_id, airport)
  values (3, 'LAX');
insert into leg_to (leg_id, airport)
  values (4, 'ORD');