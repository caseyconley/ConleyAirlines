insert into customer_reserved (customer_id, reservation_id, trip_number, seat_class)
  values (4769679843, 1, 409, 'economy');
insert into customer_reserved (customer_id, reservation_id, trip_number, seat_class)
  values (8416535295, 2, 411, 'first');
insert into customer_reserved (customer_id, reservation_id, trip_number, seat_class)
  values (4952772143, 3, 8011, 'economy');
insert into customer_reserved (customer_id, reservation_id, trip_number, seat_class)
  values (9355389592, 4, 409, 'business');