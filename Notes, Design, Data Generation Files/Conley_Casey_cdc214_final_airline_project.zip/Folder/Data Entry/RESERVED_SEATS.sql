insert into reserved_seats (reversation_id, trip_number, seat_class, customer_id, leg_id, seat_number) 
  values (1, 409, 'economy', 4769679843, 1, 1);
insert into reserved_seats (reversation_id, trip_number, seat_class, customer_id, leg_id, seat_number) 
  values (1, 409, 'economy', 4769679843, 2, 1);
insert into reserved_seats (reversation_id, trip_number, seat_class, customer_id, leg_id, seat_number)
  values (2, 411, 'first', 8416535295, 4, 341);
insert into reserved_seats (reversation_id, trip_number, seat_class, customer_id, leg_id, seat_number)
  values (3, 8011, 'economy', 4952772143, 3, 1);
insert into reserved_seat (reservation_id, trip_number, seat_class, customer_id, leg_id, seat_number)
  values (4, 409, 'business', 9355389592, 1, 281);
insert into reserved_seat (reservation_id, trip_number, seat_class, customer_id, leg_id, seat_number)
  values (4, 409, 'business', 9355389592, 2, 281);
