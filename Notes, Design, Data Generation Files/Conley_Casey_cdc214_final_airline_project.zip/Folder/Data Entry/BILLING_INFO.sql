insert into billing_info (customer_id, card_num) values (4769679843, 6098453343845904);
insert into billing_info (customer_id, card_num) values (4952772143,1035860602278262); 
insert into billing_info (customer_id, card_num) values (8416535295, 9288115810602904);
insert into billing_info (customer_id, card_num) values (9355389592,4488670974504203);